export const Notfound = () => {
  return (
    <>
        <h1 className="text-3xl">404</h1>
    </>
  )
}