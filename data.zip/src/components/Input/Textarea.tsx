import React, { forwardRef } from "react";

interface Props extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

export const Textarea = forwardRef<HTMLTextAreaElement, Props>((props, ref) => {
  return (
    <>
      <textarea
        className="border border-gray w-full px-3 py-2 rounded-md focus:outline-none"
        ref={ref}
        {...props}
      >
      </textarea>
    </>
  );
});
