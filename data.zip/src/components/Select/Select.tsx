import React, { forwardRef } from "react"

interface Props {
  children: React.ReactNode
}

export const Select = forwardRef<HTMLSelectElement, Props> (({ children }: Props, ref) => {
  return (
    <select className="border border-gray w-full px-3 py-2 rounded-md focus:outline-none mt-2" ref={ref}>
      {children}
    </select>
  )
});