export const Navbar = () => {
  return (
    <nav className="bg-gray-800 text-gray-300 text-2xl font-oswald font-bold pb-4 px-5 z-10 mb-4 border-b border-gray-400">
      <p>Kanban</p>
    </nav>
  );
};
