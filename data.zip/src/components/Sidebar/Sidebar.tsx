export const Sidebar = () => {
  return (
    <div className="w-72 h-screen bg-gray-700">
      <p className="text-2xl font-oswald font-bold text-center text-gray-300 py-4">ToDo App</p>
    </div>
  );
};
