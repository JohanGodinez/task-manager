export interface IStatus {
  id: number;
  description: string;
}
