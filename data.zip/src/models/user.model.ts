export interface IUser {
  id: number;
  name: string;
  lastname: string;
  avatar: string;
  username: string;
}