import { IStatus } from ".";

export interface ITask {
  id: number;
  startDate: Date;
  endDate: Date;
  linkbitrix: string;
  nobitrix: number;
  status: IStatus;
  title: string;
  project: string;
  description: string;
  userId: number;
}

export type TaskList = ITask[]