export interface auth 
{
  token: string;
  userId: number;
  username: string;
}
