export interface IPanel {
  id: number;
  name: string;
}

export type PanelList = IPanel[]