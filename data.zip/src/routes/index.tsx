import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import Kanban from '../pages/Kanban'
import { TaskForm } from '../components'
import Login from '../pages/Login'
import Register from '../pages/Register'

const Routers = () => {
  return (
    <>
      <div className='flex-col w-full h-screen py-4'>
        <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
          <Routes>
            <Route path='/' element={<Navigate to='./kanban' />} />
            <Route path='/kanban' element={<Kanban />}>
              <Route path='create' element={<TaskForm />} />
            </Route>
            <Route path='/login' element={<Login />}></Route>
            <Route path='/register' element={<Register />}></Route>
          </Routes>
        </BrowserRouter>
      </div>
    </>
  )
}

export default Routers