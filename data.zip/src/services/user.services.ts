import { IUser } from "../models";
import api from "./api";

export const getUsers = async (): Promise<IUser[]> => {
  try {
    const response = await api.get<IUser[]>("/users");
    return response.data;
  } catch (error) {
    console.error("Error al obtener los usuarios", error);
    throw error;
  }
};