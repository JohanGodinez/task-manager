import { ITask } from "../models";
import api from "./api";

export const getTasks = async (): Promise<ITask[]> => {
  try {
    const response = await api.get<ITask[]>("/tasks");
    return response.data;
  } catch (error) {
    console.error("Error al obtener las tareas", error);
    throw error;
  }
};