import { IPanel } from "../models";
import api from "./api";


export const getPanel = async (): Promise<IPanel[]> => {
  try {
    const response = await api.get<IPanel[]>("/panels");
    return response.data;
  } catch (error) {
    console.error("Error al obtener los panels", error);
    throw error;
  }
};