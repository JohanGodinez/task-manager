export const Card = () => {
  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Set up CI/CD</h3>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">2023-06-25</span>
          <Avatar>
            <AvatarImage src="/placeholder-user.jpg" />
            <AvatarFallback>DE</AvatarFallback>
          </Avatar>
        </div>
      </CardHeader>
    </Card>
  );
}
