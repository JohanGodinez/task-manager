const Avatar = () => {
  return (
    <div>
      <AvatarImage src="/placeholder-user.jpg" />
      <AvatarFallback>DE</AvatarFallback>
    </div>
  );
}

export default Avatar