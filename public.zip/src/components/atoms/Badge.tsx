import React from 'react'

export const Badge = () => {
  return (
    <div>Badge</div>
  )
}
