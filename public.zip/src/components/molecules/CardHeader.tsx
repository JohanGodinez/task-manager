import { Avatar } from "../atoms";

const CardHeader = () => {
  return (
    <div className="flex items-center justify-around">
      <h3 className="text-sm font-medium">Set up CI/CD</h3>
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">2023-06-25</span>
      </div>
    </div>
  );
};

export default CardHeader;
