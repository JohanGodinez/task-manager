
export const Kanban = () => {
  return (
    <main className="flex-1 p-6 grid grid-cols-4 gap-6">
      <div className="bg-card rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Pending</h2>
        </div>
        <div className="space-y-4">
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Design Mockups</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-06-30
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
        </div>
      </div>
      <div className="bg-card rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">In Progress</h2>
          <Badge variant="outline">2</Badge>
        </div>
        <div className="space-y-4">
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Implement API</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-07-31
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>DM</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
        </div>
      </div>
      <div className="bg-card rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Testing</h2>
          <Badge variant="outline">1</Badge>
        </div>
        <div className="space-y-4">
        </div>
      </div>
      <div className="bg-card rounded-lg p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Completed</h2>
          <Badge variant="outline">4</Badge>
        </div>
        <div className="space-y-4">
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Set up CI/CD</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-06-25
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>DE</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Optimize Performance</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-07-10
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Deploy to Production</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-08-01
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>SM</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="flex items-center justify-between">
              <h3 className="text-sm font-medium">Write Documentation</h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  2023-08-05
                </span>
                <Avatar>
                  <AvatarImage src="/placeholder-user.jpg" />
                  <AvatarFallback>JW</AvatarFallback>
                </Avatar>
              </div>
            </CardHeader>
          </Card>
        </div>
      </div>
    </main>
  );
}
