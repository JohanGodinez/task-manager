
function App() {
  return (
    <>
      <header className="bg-primary text-primary-foreground py-4 px-6 flex items-center justify-between">
        <h1 className="text-3xl font-bold">Kanban Board</h1>
        <button>Add New Task</button>
      </header>
    </>
  );
}

export default App
